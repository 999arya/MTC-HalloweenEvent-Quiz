# The Crypt Trials

Halloween quiz pre-site using the supplied Microsoft Tech Community assets and original theme stylesheet.

Open `dist/index.html` in a browser. No build tools or installation are needed. Upload the contents of `dist` to any static web host.

## Replace the sample questions

Edit `dist/questions.js`. Each entry contains `question`, `options`, `correctAnswer` (zero-based), and `explanation`. The question count and score update automatically. Remove the preview/sample labels in `dist/index.html` when the final questions are added.

The current flow supports one correct answer per question. Answers stay in memory only; reloading resets the quiz. No responses are sent to a server. Scores are practice feedback, not secure qualification results. Sound is off by default and can be enabled with the top-right button. Google Fonts require an internet connection; local fallback fonts are provided.

`build.cjs` was used to assemble the original atmosphere into the initial page. Edit the delivered HTML directly; running that assembly script again overwrites it.
